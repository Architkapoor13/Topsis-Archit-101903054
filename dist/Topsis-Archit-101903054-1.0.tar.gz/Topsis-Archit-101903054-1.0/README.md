# Topsis-Archit-101903054
It takes an integer as an input and prints it square.

## Installation
```pip install saral-square```

## How to use it?
Open terminal and type square and then input the integer

## License

© 2022 Archit Kapoor

This repository is licensed under the MIT license. See LICENSE for details.